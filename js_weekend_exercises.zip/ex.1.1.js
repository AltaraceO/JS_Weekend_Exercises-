const basic = (bool) => (bool ? "yes" : "no");

console.log(basic(true));
